<?php return array('dependencies' => array(), 'version' => '4d04e0384ecd085abe4c');
