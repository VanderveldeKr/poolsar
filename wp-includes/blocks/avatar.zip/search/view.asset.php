<?php return array('dependencies' => array(), 'version' => '3eb70ca99788ad066a38');
