<?php return array('dependencies' => array(), 'version' => 'c6277d25063d1381b56e');
