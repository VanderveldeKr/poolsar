<?php return array('dependencies' => array(), 'version' => '886680af40b7521d60fc');
