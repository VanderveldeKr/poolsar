<?php
/**
 * Deprecated. No longer needed.
 *
 * @package WordPress
 * @deprecated 3.1.0
 */

_deprecated_file( basename( __FILE__ ), '3.1.0', '', __( 'This file no longer needs to be included.' ) );
