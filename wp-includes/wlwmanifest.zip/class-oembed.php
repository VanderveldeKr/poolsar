<?php
/**
 * API for fetching the HTML to embed remote content based on a provided URL.
 *
 * This file is deprecated, use 'wp-includes/class-wp-oembed.php' instead.
 *
 * @deprecated 5.3.0
 * @package WordPress
 * @subpackage oEmbed
 */

_deprecated_file( basename( __FILE__ ), '5.3.0', WPINC . '/class-wp-oembed.php' );

/** WP_oEmbed class */
require_once ABSPATH . WPINC . '/class-wp-oembed.php';
